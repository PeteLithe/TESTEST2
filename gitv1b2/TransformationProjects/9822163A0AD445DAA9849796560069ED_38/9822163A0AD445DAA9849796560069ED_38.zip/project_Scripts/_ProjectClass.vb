Option Explicit

' Project Script

Private Sub TakeMultilineTextFromKvpLocator(ByVal pXDoc As CASCADELib.CscXDocument)
   If Not pXDoc.Locators.Exists("KVP") Then
      Exit Sub
   End If

   Dim kvpLocator As CscXDocField
   Set kvpLocator = pXDoc.Locators.ItemByName("KVP")

   Dim fieldIndex, fieldCount As Integer
   fieldCount = pXDoc.Fields.Count

   ' Loop over all fields
   For fieldIndex = 0 To fieldCount - 1
      Dim field As CscXDocField
      Set field = pXDoc.Fields.ItemByIndex(fieldIndex)

      Dim alternativesIndex, alternativesCount As Integer
      alternativesCount = kvpLocator.Alternatives.Count

      ' Loop over all alternatives of the key-value-pair locator
      For alternativesIndex = 0 To alternativesCount - 1
         Dim alternative As CscXDocFieldAlternative
         Set alternative = kvpLocator.Alternatives(alternativesIndex)

         Dim subFieldsIndex, subFieldsCount As Integer
         subFieldsCount = alternative.SubFields.Count

         ' Loop over all sub fields of the key-value-pair locator alternative
         For subFieldsIndex = 0 To subFieldsCount - 1
             Dim subField As CscXDocSubField
             Set subField = alternative.SubFields(subFieldsIndex)

             ' Check if the sub field name and the field name are equal
             If subField.Name = field.Name Then
               ' Check if the sub field text is not equal to the field text, but contains the field text
               If subField.Text <> field.Text And InStr(subField.Text, field.Text) > 0 Then
                  ' Check whether the field rectangle is contained in the subfield rectangle
                  If field.Left >= subField.Left And field.Top >= subField.Top And (field.Left + field.Width) <= (subField.Left + subField.Width) And (field.Top + field.Height) <= (subField.Top + subField.Height) Then
                      ' Transfer the sub field data to the field data
                      field.Text = subField.Text
                      field.Left = subField.Left
                      field.Top = subField.Top
                      field.Width = subField.Width
                      field.Height = subField.Height

                      Exit For
                  End If
               End If
             End If
         Next
      Next
   Next
End Sub

Private Sub Document_AfterExtract(ByVal pXDoc As CASCADELib.CscXDocument)
    TakeMultilineTextFromKvpLocator(pXDoc)
End Sub
